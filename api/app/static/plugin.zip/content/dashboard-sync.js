(function () {
  "use strict";

  const SITE_KEY = "obs_user_id";
  const PLUGIN_KEY = "anonymousUserId";
  const UUID_RE = /^[0-9a-fA-F]{8}-(?:[0-9a-fA-F]{4}-){3}[0-9a-fA-F]{12}$/;

  async function restoreDashboardIdentity() {
    try {
      // 不覆盖用户通过“身份管理”主动选择的身份，只在缺失时补齐。
      if (localStorage.getItem(SITE_KEY)) return;
      const stored = await chrome.storage.local.get(PLUGIN_KEY);
      const pluginUid = stored[PLUGIN_KEY];
      if (typeof pluginUid !== "string" || !UUID_RE.test(pluginUid)) return;
      localStorage.setItem(SITE_KEY, pluginUid.toLowerCase());
      // 看板脚本可能已在异步读取插件存储期间启动，刷新确保所有请求使用同一身份。
      location.reload();
    } catch {
      // 站点存储不可用时保留原有看板流程，避免刷新循环。
    }
  }

  void restoreDashboardIdentity();
})();
